## About me

I find life better, and I'm happier, when things are nice and simple.



## Recent posts 

### Keeping cooking simple

### Simplicity and work

### Simple decorations
